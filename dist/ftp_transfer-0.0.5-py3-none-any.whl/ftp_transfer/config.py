import os
import yaml
import getpass
import traceback
from loguru import logger
from typing import Dict, Any

def load_config(config_path: str) -> Dict[str, Any]:
    """
    加载YAML配置文件
    
    :param config_path: 配置文件路径
    :return: 配置字典
    """
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
            logger.info(f"成功加载配置文件: {config_path}")
            return config
    except FileNotFoundError:
        logger.error(f"配置文件不存在: {config_path}")
        logger.debug(traceback.format_exc())
        raise
    except yaml.YAMLError as e:
        logger.error(f"配置文件格式错误: {str(e)}")
        logger.debug(traceback.format_exc())
        raise
    except Exception as e:
        logger.error(f"加载配置文件失败: {str(e)}")
        logger.debug(traceback.format_exc())
        raise

def create_config(config_path: str) -> None:
    """
    创建配置文件，引导用户填写必要的配置信息
    
    :param config_path: 配置文件保存路径
    """
    print("首次运行，需要创建配置文件...")
    
    # 创建配置目录（如果不存在）
    config_dir = os.path.dirname(config_path)
    if config_dir and not os.path.exists(config_dir):
        os.makedirs(config_dir)
        logger.info(f"创建配置目录: {config_dir}")
    
    # 引导用户填写配置信息
    config = {
        'source': {
            'host': input("请输入源FTP服务器地址: "),
            'port': int(input("请输入源FTP端口 (默认为21): ") or "21"),
            'user': input("请输入源FTP用户名: "),
            'password': getpass.getpass("请输入源FTP密码: "),
            'directory': input("请输入源FTP目录路径: "),
            'backup_directory': input("请输入源FTP备份目录路径 (用于文件处理后备份): "),
            'encoding': input("请输入源FTP编码 (默认为'utf-8', windows系统请输入'gbk'): ") or "utf-8",
        },
        'destination': {
            'host': input("请输入目标FTP服务器地址: "),
            'port': int(input("请输入目标FTP端口 (默认为21): ") or "21"),
            'user': input("请输入目标FTP用户名: "),
            'password': getpass.getpass("请输入目标FTP密码: "),
            'directory': input("请输入目标FTP目录路径: "),
            'encoding': input("请输入目标FTP编码 (默认为'utf-8', windows系统请输入'gbk'): ") or "utf-8",
        },
        'log': {
            'file': input("请输入日志文件路径 (默认为'ftp_transfer.log'): ") or "ftp_transfer.log",
            'rotation': input("请输入日志轮转策略 (默认为'1 week'): ") or "1 week",
            'retention': input("请输入日志保留时间 (默认为'1 month'): ") or "1 month",
            'level': input("请输入日志级别 (默认为'INFO'): ") or "INFO"
        },
        'email': {
            'enable': input("是否启用邮件通知? (y/n, 默认n): ").lower() == 'y',
        }
    }
    
    # 如果启用邮件通知，继续填写邮件配置
    if config['email']['enable']:
        config['email'].update({
            'subject': input("请输入邮件主题 (默认为'FTP文件传输任务报告'): ") or "FTP文件传输任务报告",
            'sender': input("请输入发送者邮箱: "),
            'recipients': input("请输入接收者邮箱 (多个邮箱用逗号分隔): ").split(','),
            'smtp_server': input("请输入SMTP服务器地址: "),
            # 'smtp_port': int(input("请输入SMTP服务器端口 (默认为465): ") or "465"),
            'smtp_port': '465',
            'smtp_username': input("请输入SMTP用户名: "),
            'smtp_password': getpass.getpass("请输入SMTP密码或授权码: "),
            'failure_threshold': int(input("请输入失败文件数量阈值 (默认为3): ") or "3")
        })
    
    # 写入配置文件
    with open(config_path, 'w', encoding='utf-8') as f:
        yaml.dump(config, f, allow_unicode=True, default_flow_style=False)
        
    logger.info(f"配置文件已创建: {config_path}")
    print(f"配置文件已创建成功: {config_path}")
